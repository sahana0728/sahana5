package com.xyz;

public class HelloJenkinsfile {
	
	public String go(){
		return "HelloJenkinsfile";
	}

}
