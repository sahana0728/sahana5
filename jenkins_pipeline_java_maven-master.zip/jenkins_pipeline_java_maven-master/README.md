"TTFHW" [is a recently popular](https://sendgrid.com/blog/three-ways-to-decrease-time-to-first-hello-world/) short-hand for Time To First Hello World, [also see this blog](https://betterologist.net/2016/08/jenkins-pipeline-ttfhw/).

|[**_author_**](https://betterologist.net/2016/06/jammazwan-for-hire/)|Time To First Hello World|[TL;DR? _about:_](https://youtu.be/lb0kqQYfNJw)|
| --- | --- | --- |
|<img class="style-svg" src="https://betterologist.net/wp-content/uploads/2016/05/pete-300x297.jpg" alt="pete" width="116" height="115" />|<img class="style-svg" src="https://betterologist.net/wp-content/uploads/2016/08/clockface.png" alt="jammazwanPhotoSmall" width="200" height="116" />|[<img class="style-svg" src="https://betterologist.net/wp-content/uploads/2016/08/jenkinsPipelineThumbnail.png" alt="about" width="115" height="115" />](https://youtu.be/lb0kqQYfNJw)|
##### Ready to run example Jenkins Pipeline project, runnable in Jenkins CI server in 60 seconds
---

### jenkins_pipeline_java_maven 

Functionality: **_Example of a Jenkins Pipeline project that would build a java project_**

---

see [this video tutorial](https://youtu.be/lb0kqQYfNJw) for how to run this project in your Jenkins server